import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Member_List extends JFrame implements MouseListener, ActionListener {

    Vector v;
    Vector cols;
    DefaultTableModel model;
    JTable jTable;
    JScrollPane pane;
    JPanel pbtn;
    JButton btnInsert;
    JButton btnSearch;
    JButton BtnReset;

    JTextField txtSearch;
    JComboBox<String> cmbGender; // 콤보 박스 필드로 선언

    public Member_List() {
        super("회원 관리 프로그램");
        MemberDAO dao = new MemberDAO();
        v = dao.getMemberList();
        System.out.println("v=" + v);
        cols = getColumn();

        model = new DefaultTableModel(v, cols);

        jTable = new JTable(model);
        pane = new JScrollPane(jTable);
        add(pane);

        pbtn = new JPanel();
        btnInsert = new JButton("회원 추가");
        pbtn.add(btnInsert);
        add(pbtn, BorderLayout.NORTH);

        cmbGender = new JComboBox<String>();
        pbtn.add(cmbGender);
        add(pbtn, BorderLayout.NORTH);

        cmbGender.setModel(new DefaultComboBoxModel<String>(new String[]{"선택", "여성", "남성"}));

        txtSearch = new JTextField();
        pbtn.add(txtSearch);
        add(pbtn, BorderLayout.NORTH);

        txtSearch.setPreferredSize(new Dimension(200, txtSearch.getPreferredSize().height));

        btnSearch = new JButton("조회");
        pbtn.add(btnSearch);
        add(pbtn, BorderLayout.NORTH);

        BtnReset = new JButton("전체 조회");
        pbtn.add(BtnReset);
        add(pbtn, BorderLayout.NORTH);

        jTable.addMouseListener(this);
        btnInsert.addActionListener(this);
        btnSearch.addActionListener(this);
        BtnReset.addActionListener(this);

        setSize(1000, 700);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public Vector getColumn() {
        Vector col = new Vector();
        col.add("아이디");
        col.add("비밀번호");
        col.add("이름");
        col.add("전화");
        col.add("주소");
        col.add("생일");
        col.add("직업");
        col.add("성별");
        col.add("이메일");
        col.add("비고");

        return col;
    }

    public void jTableRefresh() {
        MemberDAO dao = new MemberDAO();
        DefaultTableModel model = new DefaultTableModel(dao.getMemberList(), getColumn());
        jTable.setModel(model);
    }

    public static void main(String[] args) {
        new Member_List();
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        int r = jTable.getSelectedRow();
        String id = (String) jTable.getValueAt(r, 0);
        MemberProc mem = new MemberProc(id, this);
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnInsert) {
            new MemberProc(this);
        } else if (e.getSource() == btnSearch) {
            String selectedValue = (String) cmbGender.getSelectedItem();
            String filter;
            if(selectedValue == "선택") {
            	filter = "";
            }
            else if(selectedValue == "여성") {
            	filter = "W";
            }
            else{
            	filter = "M";
            }
            
            String keyword = txtSearch.getText();
            MemberDAO dao = new MemberDAO();
            dao.userSelectSearch(model, keyword, filter);
            model.fireTableDataChanged();
            jTable.updateUI();
            jTable.requestFocusInWindow();
        } else if (e.getSource() == BtnReset) {
            MemberDAO dao = new MemberDAO();
            dao.userSelectAll(model);
            model.fireTableDataChanged();
            jTable.updateUI();
            jTable.requestFocusInWindow();
        }
    }
}
